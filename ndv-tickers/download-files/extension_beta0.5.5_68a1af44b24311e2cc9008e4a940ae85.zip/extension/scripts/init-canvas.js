// main canvas
const canvas1 = document.getElementById('sample1');
const context = canvas1.getContext('2d');
// clock canvas
const canvas2 = document.getElementById('sample2');
const time = canvas2.getContext('2d');
// 気象速報サブタイトル
const canvas3 = document.createElement("canvas");
const ctx3 = canvas3.getContext('2d');
// // 左側三角
// const canvas4 = document.createElement("canvas");
// canvas4.width = "230px";
// canvas4.height = "68px";
// const ctx4 = canvas3.getContext('2d');
// // 右側三角その他
// const canvas5 = document.createElement("canvas");
// canvas5.width = "30px";
// canvas5.height = "68px";
// const ctx5 = canvas3.getContext('2d');
// // メインテキスト仮保存
// const canvas6 = document.createElement("canvas");
// canvas6.width = "2160px";
// canvas6.height = "68px";
// const ctx6 = canvas3.getContext('2d');
